﻿namespace RabbitMessaging.Messenger.Interfaces
{
    public interface IMessageAdaptor
    {
        void Send(string queue, string data);
        string Receive(string queue);
    }
}
