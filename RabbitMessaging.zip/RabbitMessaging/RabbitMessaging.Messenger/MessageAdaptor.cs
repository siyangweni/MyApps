﻿using RabbitMessaging.Messenger.Interfaces;
using RabbitMQ.Client;
using System;
using System.Text;

namespace RabbitMessaging.Messenger
{
    public class MessageAdaptor : IMessageAdaptor
    {
        #region Method(s)
        public IConnection GetConnection(string hostName, string userName, string password)
        {
            ConnectionFactory connectionFactory = new ConnectionFactory();
            connectionFactory.HostName = hostName;
            connectionFactory.UserName = userName;
            connectionFactory.Password = password;
            return connectionFactory.CreateConnection();
        }

        public void Send(string queue, string data)
        {
            try
            {
                using (IConnection connection = new ConnectionFactory().CreateConnection())
                {
                    using (IModel channel = connection.CreateModel())
                    {
                        channel.QueueDeclare(queue, false, false, false, null);
                        channel.BasicPublish(string.Empty, queue, null, Encoding.UTF8.GetBytes(data));
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public string Receive(string queue)
        {
            try
            {
                using (IConnection connection = new ConnectionFactory().CreateConnection())
                {
                    using (IModel channel = connection.CreateModel())
                    {
                        channel.QueueDeclare(queue, false, false, false, null);

                        BasicGetResult result = channel.BasicGet(queue, true);
                        if (result != null)
                        {
                            return Encoding.UTF8.GetString(result.Body);
                        }
                        else
                            return "";
                    }
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        #endregion
    }
}