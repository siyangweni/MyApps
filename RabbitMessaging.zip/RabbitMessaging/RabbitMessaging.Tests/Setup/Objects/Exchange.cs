﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace RabbitMessaging.Tests.Setup.Objects
{
    public class Exchange
    {
        #region Declaration(s)
        public IDictionary<string, object> Arguments = new Dictionary<string, object>();

        public ConcurrentQueue<Message> Messages = new ConcurrentQueue<Message>();
        public ConcurrentDictionary<string, ExchangeQueueBinding> Bindings = new ConcurrentDictionary<string, ExchangeQueueBinding>();
        #endregion

        #region Propertie(s)

        public string Name { get; set; }

        public string Type { get; set; }

        public bool IsDurable { get; set; }

        public bool AutoDelete { get; set; }

        #endregion


        #region Method(s)

        public void PublishMessage(Message message)
        {
            this.Messages.Enqueue(message);

            if (string.IsNullOrWhiteSpace(message.RoutingKey))
            {
                foreach (var binding in Bindings)
                {
                    binding.Value.Queue.PublishMessage(message);
                }
            }
            else
            {
                var matchingBindings = Bindings
                    .Values
                    .Where(b => b.RoutingKey == message.RoutingKey);

                foreach (var binding in matchingBindings)
                {
                    binding.Queue.PublishMessage(message);
                }
            }
        }

        #endregion
    }
}