﻿using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMessaging.Tests.Setup.Objects
{
    public class Message
    {
        #region Propertie(s)

        public string Exchange { get; set; }

        public string RoutingKey { get; set; }

        public string Queue { get; set; }

        public bool Mandatory { get; set; }

        public bool Immediate { get; set; }

        public IBasicProperties BasicProperties { get; set; }

        public byte[] Body { get; set; }
        #endregion

        #region Method(s)

        public Message Copy()
        {
            return new Message
            {
                Exchange = Exchange,
                RoutingKey = RoutingKey,
                Queue = Queue,
                Mandatory = Mandatory,
                Immediate = Immediate,
                BasicProperties = BasicProperties,
                Body = Body
            };
        }
        #endregion
    }
}
