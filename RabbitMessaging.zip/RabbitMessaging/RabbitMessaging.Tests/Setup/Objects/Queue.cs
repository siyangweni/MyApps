﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;

namespace RabbitMessaging.Tests.Setup.Objects
{
    public class Queue
    {

        #region Declaration(s)

        public Dictionary<string, object> Arguments = new Dictionary<string, object>();

        public ConcurrentQueue<Message> Messages = new ConcurrentQueue<Message>();

        public ConcurrentDictionary<string, ExchangeQueueBinding> Bindings = new ConcurrentDictionary<string, ExchangeQueueBinding>();
        #endregion

        #region Propertie(s)

        public string Name { get; set; }
        public bool IsDurable { get; set; }

        public bool IsExclusive { get; set; }
        public bool IsAutoDelete { get; set; }
        #endregion

        #region EventHandler(s)

        public event EventHandler<Message> MessagePublished = (sender, message) => { };
        #endregion

        #region Method(s)

        public void PublishMessage(Message message)
        {
            var queueMessage = message.Copy();
            queueMessage.Queue = this.Name;

            this.Messages.Enqueue(queueMessage);

            MessagePublished(this, queueMessage);
        }
        #endregion
    }
}
