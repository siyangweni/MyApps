﻿using RabbitMessaging.Tests.Setup.Objects;
using System.Collections.Concurrent;
namespace RabbitMessaging.Tests.Setup
{
    public class RabbitServer
    {
        #region Declaration(s)
        public ConcurrentDictionary<string, Exchange> Exchanges = new ConcurrentDictionary<string, Exchange>();
        public ConcurrentDictionary<string, Queue> Queues = new ConcurrentDictionary<string, Queue>();

        #endregion

        #region Method(s)
        public void Reset()
        {
            Exchanges.Clear();
            Queues.Clear();
        }
        #endregion
    }
}
