﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace RabbitMessaging.Tests.Setup
{
    public class MockConnection : IConnection
    {
        #region Declaration(s)
        private readonly RabbitServer _server;
        #endregion

        #region Ctor(s)
        public MockConnection(RabbitServer server)
        {
            _server = server;
            Models = new List<MockModel>();
        }
        #endregion

        #region Propertie(s)

        public List<MockModel> Models { get; private set; }


        public EndPoint LocalEndPoint { get; set; }


        public EndPoint RemoteEndPoint { get; set; }


        public int LocalPort { get; set; }

        public int RemotePort { get; set; }


        public AmqpTcpEndpoint Endpoint { get; set; }

        public IProtocol Protocol { get; set; }

        IDictionary<string, object> IConnection.ServerProperties
        {
            get { throw new NotImplementedException(); }
        }

        IList<ShutdownReportEntry> IConnection.ShutdownReport
        {
            get { throw new NotImplementedException(); }
        }

        public string ClientProvidedName { get; }

        public ConsumerWorkService ConsumerWorkService { get; }

        event EventHandler<CallbackExceptionEventArgs> IConnection.CallbackException
        {
            add { throw new NotImplementedException(); }
            remove { throw new NotImplementedException(); }
        }

        public event EventHandler<ConnectionBlockedEventArgs> ConnectionBlocked;
        event EventHandler<ShutdownEventArgs> IConnection.ConnectionShutdown
        {
            add { throw new NotImplementedException(); }
            remove { throw new NotImplementedException(); }
        }

        event EventHandler<ConnectionRecoveryErrorEventArgs> IConnection.ConnectionRecoveryError
        {
            add
            {
                throw new NotImplementedException();
            }

            remove
            {
                throw new NotImplementedException();
            }
        }

        event EventHandler<ConnectionBlockedEventArgs> IConnection.ConnectionBlocked
        {
            add
            {
                throw new NotImplementedException();
            }

            remove
            {
                throw new NotImplementedException();
            }
        }

        public event EventHandler<EventArgs> ConnectionUnblocked;


        public event EventHandler<EventArgs> RecoverySucceeded;

        public event EventHandler<ConnectionRecoveryErrorEventArgs> ConnectionRecoveryError;
        public event EventHandler<CallbackExceptionEventArgs> CallbackException;


        public ShutdownEventArgs CloseReason { get; set; }

        public bool IsOpen { get; set; }
        public bool AutoClose { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public ushort ChannelMax => throw new NotImplementedException();

        public IDictionary<string, object> ClientProperties => throw new NotImplementedException();

        public uint FrameMax => throw new NotImplementedException();

        public ushort Heartbeat => throw new NotImplementedException();

        public AmqpTcpEndpoint[] KnownHosts => throw new NotImplementedException();

        #endregion

        #region Method(s)
        public void Dispose()
        {

        }

        public void Abort()
        {
            throw new NotImplementedException();
        }

        public void Abort(ushort reasonCode, string reasonText)
        {
            throw new NotImplementedException();
        }

        public void Abort(int timeout)
        {
            throw new NotImplementedException();
        }

        public void Abort(ushort reasonCode, string reasonText, int timeout)
        {
            throw new NotImplementedException();
        }

        public void Close()
        {
            throw new NotImplementedException();
        }

        public void Close(ushort reasonCode, string reasonText)
        {
            throw new NotImplementedException();
        }

        public void Close(int timeout)
        {
            throw new NotImplementedException();
        }

        public void Close(ushort reasonCode, string reasonText, int timeout)
        {
            throw new NotImplementedException();
        }

        public IModel CreateModel()
        {
            throw new NotImplementedException();
        }

        public void HandleConnectionBlocked(string reason)
        {
            throw new NotImplementedException();
        }

        public void HandleConnectionUnblocked()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
