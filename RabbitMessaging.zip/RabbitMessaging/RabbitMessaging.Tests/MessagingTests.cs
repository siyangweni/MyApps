﻿using NUnit.Framework;
using RabbitMessaging.Tests.Setup;
using System.Text;

namespace RabbitMessaging.Tests
{
    [TestFixture]
    public class MessagingTests : BaseTester
    {
        #region Test Method
        [Test]
        public void ReceiveSentMessages()
        {
            var server = new RabbitServer();

            ConfigureQueueBinding(server, "test_server", "hello_queue");

            SendMessage(server, "test_server", "Hello my name is, Siya");

            var connectionFactory = new MockConnectionFactory(server);

            using (var connection = connectionFactory.CreateConnection())
            {
                using (var channel = connection.CreateModel())
                {
                    var message = channel.BasicGet("hello_queue", false);

                    Assert.That(message, Is.Not.Null);

                    var messageBody = Encoding.ASCII.GetString(message.Body);

                    Assert.That(messageBody, Is.EqualTo("Hello my name is, Siya"));

                    channel.BasicAck(message.DeliveryTag, multiple: false);
                }
            }
        }
        #endregion
    }
}
