﻿using System;
using RabbitMessaging.Messenger;
using RabbitMessaging.Receiver.Implementation;

namespace RabbitMessaging.Receiver
{
    class Program
    {
        #region const variables
        private const string QUEUE_NAME = "Hello";
        #endregion

        #region Method(s)
        static void Main(string[] args)
        {
            try
            {
                var adaptor = new MessageAdaptor();

                string message = MessageReceiver.ReceiveMessage(adaptor ,QUEUE_NAME);

                if (string.IsNullOrWhiteSpace(message))
                {
                    Console.WriteLine($"No messages to read from queue ({QUEUE_NAME})");
                    return;
                }

                var name = message.Substring(message.LastIndexOf(',')).Trim();
                
                Console.WriteLine($"Hello {name}, I am your father!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.Read();
            }
        }
        #endregion
    }
}