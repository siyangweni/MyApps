﻿using RabbitMessaging.Messenger.Interfaces;
using System;

namespace RabbitMessaging.Receiver.Implementation
{
    public static class MessageReceiver
    {
        public static string ReceiveMessage(IMessageAdaptor messageAdaptor, string queue)
        {
            try
            {
                return messageAdaptor.Receive(queue);
               
            }catch(Exception exc)
            {
                throw exc;
            }
        }
    }
}
