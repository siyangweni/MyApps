﻿using System;
using RabbitMessaging.Messenger.Interfaces;

namespace RabbitMessaging.Sender.Implementation
{
    public static class MessageSender
    {
        public static void SendMessage(IMessageAdaptor messageAdaptor, string queue, string data)
        {
            try
            {
                messageAdaptor.Send(queue, data);
            }catch(Exception exc)
            {
                throw exc;
            }
        }
    }
}
