﻿using System;
using RabbitMessaging.Messenger;
using RabbitMessaging.Sender.Implementation;

namespace RabbitMessaging
{
    class Program
    {
        #region Declaration(s)
        private const string QUEUE_NAME = "Hello";
        #endregion


        #region Method(s)
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Please enter name:");

                string name = Console.ReadLine();

                var adaptor = new MessageAdaptor();

                MessageSender.SendMessage(adaptor, QUEUE_NAME, $"Hello my name is, {name}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.Read();
            }
        }
        #endregion
    }
}
