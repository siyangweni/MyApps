﻿using System;
using System.Linq;
using StructureMap;
using TwitterFeedsApp.CrossCuttingConcerns.Contracts;
using TwitterFeedsApp.Web.Contracts;
using TwitterFeedsApp.Web.ServiceReference;
using TwitterFeedsApp.WebSite.Models;
using Tweet = TwitterFeedsApp.WebSite.Models.Tweet;

namespace TwitterFeedsApp.Web.Factories
{
    public class News24TwitterPageViewModelFactory : INews24TwitterPageViewModelFactory
    {
        public News24TwitterPageViewModel Initialize(string twitterUser, int count)
        {
            var viewModel = new News24TwitterPageViewModel
            {
                Heading = "News24 tweets"
            };

            try
            {

                ServiceClient serviceClient = new ServiceClient("BasicHttpBinding_IService");
                var request = new TwitterFeedsRequest
                {
                    TwitterUser = twitterUser,
                    NumberOfFeedsToRetrieve = count
                };

                var tweets = serviceClient.RetrieveUserTweets(request).ToList();

                if (tweets.Any())
                {
                    viewModel.Tweets = tweets.Select(x => new Tweet { Content = x.text, Time = x.created_at });
                }
            }
            catch (Exception exception)
            {
                var errorLogger = ObjectFactory.GetInstance<ILogger>();
                errorLogger.FatalError(exception);
                viewModel.ErrorMessage = "An error occured while trying to retreive feeds, please try again later.";
            }

            return viewModel;
        }
    }
}