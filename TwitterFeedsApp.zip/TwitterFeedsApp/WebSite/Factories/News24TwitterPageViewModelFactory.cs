﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using StructureMap;
using TwitterFeedsApp.CrossCuttingConcerns.Contracts;
using TwitterFeedsApp.Web.Contracts;
using TwitterFeedsApp.WebSite.Models;

namespace TwitterFeedsApp.Web.Factories
{
    public class News24TwitterPageViewModelFactory : INews24TwitterPageViewModelFactory
    {
        public News24TwitterPageViewModel Initialize(string twitterUser, string count)
        {
            var viewModel = new News24TwitterPageViewModel
            {
                Heading = "News24 tweets"
            };

            try
            {
             
                var serviceUrl = ConfigurationManager.AppSettings["WebServiceEndpoint"];
                var requestUrl = string.Format("{0}?username={1}&count={2}", serviceUrl, twitterUser, count);

                var getRequest = (HttpWebRequest)WebRequest.Create(requestUrl);
                getRequest.Method = "GET";

                Console.WriteLine("Sending GET Request");
                var getResponse = (HttpWebResponse)getRequest.GetResponse();
                var getResponseStream = getResponse.GetResponseStream();
                var sr = new StreamReader(getResponseStream);
            
                Console.WriteLine("Response from Server");
                Console.WriteLine(sr.ReadToEnd());
                Console.ReadLine();
                //TODO: Map to viewmodel

            }
            catch (Exception exception)
            {
                var errorLogger = ObjectFactory.GetInstance<ILogger>();
                errorLogger.FatalError(exception);
                viewModel.ErrorMessage = "An error occured while trying to retreive feeds, please try again later.";
            }

            return viewModel;
        }
    }
}