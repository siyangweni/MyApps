﻿using TwitterFeedsApp.WebSite.Models;

namespace TwitterFeedsApp.Web.Contracts
{
    public interface INews24TwitterPageViewModelFactory
    {
        News24TwitterPageViewModel Initialize(string twitterUser, int count);
    }
}
