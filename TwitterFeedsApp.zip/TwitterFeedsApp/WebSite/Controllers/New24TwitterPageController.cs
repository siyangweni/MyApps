﻿using System.Configuration;
using System.Web.Mvc;
using StructureMap;
using TwitterFeedsApp.Web.Contracts;

namespace TwitterFeedsApp.Web.Controllers
{
    public class New24TwitterPageController : Controller
    {
        public New24TwitterPageController()
        {
        }

        //
        // GET: /New24TwitterPage/
        public ActionResult Index()
        {
            var news24TwitterUser = ConfigurationManager.AppSettings["News24TwitterUser"];
            var news24TwitterCount = int.Parse(ConfigurationManager.AppSettings["News24TwitterCount"]);
            var news24TwitterPageViewModelFactory = ObjectFactory.GetInstance<INews24TwitterPageViewModelFactory>();

            var viewModel = news24TwitterPageViewModelFactory.Initialize(news24TwitterUser, news24TwitterCount);

            return View(viewModel);
        }

    }
}
