﻿using StructureMap;
using TwitterFeedsApp.CrossCuttingConcerns;
using TwitterFeedsApp.CrossCuttingConcerns.Contracts;
using TwitterFeedsApp.Web.Contracts;
using TwitterFeedsApp.Web.Factories;

namespace TwitterFeedsApp.Web.Infrastructure
{
    public static class IOCContainter
    {
        public static void Initialize()
        {
            ObjectFactory.Initialize(x =>
            {
                x.For<INews24TwitterPageViewModelFactory>().Use<News24TwitterPageViewModelFactory>();
                x.For<ILogger>().Use<Logger>();
            });
        }
    }
}