﻿using System;

namespace TwitterFeedsApp.WebSite.Models
{
    public class Tweet
    {
        public string UserName { get; set; }
        public DateTime Time { get; set; }
        public string Content { get; set; }
    }
}