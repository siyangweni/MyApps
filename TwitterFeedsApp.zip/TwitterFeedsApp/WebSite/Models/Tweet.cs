﻿namespace TwitterFeedsApp.WebSite.Models
{
    public class Tweet
    {
        public string Time { get; set; }
        public string Content { get; set; }
    }
}