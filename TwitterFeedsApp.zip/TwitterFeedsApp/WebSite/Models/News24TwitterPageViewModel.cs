﻿using System.Collections.Generic;

namespace TwitterFeedsApp.WebSite.Models
{
    public class News24TwitterPageViewModel
    {
        public string Heading { get; set; }
        public string ErrorMessage { get; set; }
        public IEnumerable<Tweet> Tweets { get; set; }
    }
}