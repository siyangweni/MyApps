﻿namespace TwitterFeedsApp.RestWebService
{
    public class TwitterResponse
    {
        public string token_type { get; set; }
        public string access_token { get; set; }
    }
}
