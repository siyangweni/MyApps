﻿using System;
using System.Web;
using System.Configuration;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using TwitterFeedsApp.RestWebService;

using System.Net.Http;

namespace RestWebService
{
    public class Service:IHttpHandler
    {
        #region Private Members

        #endregion

        #region Handler
        bool IHttpHandler.IsReusable
        {
            get { throw new NotImplementedException(); }
        }

        void IHttpHandler.ProcessRequest(HttpContext context)
        {
            try
            {                
                switch (context.Request.HttpMethod)
                {
                    case "GET":
                        //Perform READ Operation                   
                        ReadTweets(context);
                        break;

                }
            }
            catch (Exception ex)
            {
               
            }
        }

        #endregion Handler
        private async void ReadTweets(HttpContext context)
        {
            try
            {
                int count = Convert.ToInt16(context.Request["count"]);
                var userName = context.Request["username"];
   
                var twitterAPI = string.Format(ConfigurationManager.AppSettings["TwitterAPI"], userName, count);
                var twitterAppName = ConfigurationManager.AppSettings["TwitterAppName"];

                string bearer = GetBearerAsync().Result;

                using (var client = new HttpClient())
                {
                    string auth = "Bearer " + bearer;

                    client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", auth);
                    client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", twitterAppName);

                    var response = await client.GetAsync(twitterAPI);
                    var responseContent = await response.Content.ReadAsStringAsync();

                    WriteResponse(responseContent);
                }
                    
            }
            catch (Exception ex)
            {
                
            }
        }

        #region Utility Functions
        static async Task<string> GetBearerAsync()
        {
            using (var client = new HttpClient())
            {
                string key = ConfigurationManager.AppSettings["TwitterKey"];
                string secret = ConfigurationManager.AppSettings["TwitterSecret"];

                string keyEncoded = HttpUtility.UrlEncode(key);
                string secretEncoded = HttpUtility.UrlEncode(secret);

                string keySecretEncoded = Base64Encode(keyEncoded + ":" + secretEncoded);
                string credentials = ("Basic " + keySecretEncoded);

                string uri = "https://api.twitter.com/oauth2/token";
                string contentType = "application/x-www-form-urlencoded;charset=UTF-8";
                //Add headers, skip validation that throws false errors
                client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", credentials);
                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", contentType);

                //post body
                var values = new Dictionary<string, string> { { "grant_type", "client_credentials" } };
                var body = new FormUrlEncodedContent(values);

                var response = await client.PostAsync(uri, body);
                var payload = await response.Content.ReadAsStringAsync();

                //Deserialize JSON into TwitterResponse object
                var ser = new JavaScriptSerializer();
                TwitterResponse TwitterResponse = ser.Deserialize<TwitterResponse>(payload);

                string bearer = TwitterResponse.access_token;

                return bearer;
            }
        }

        private static void WriteResponse(string strMessage)
        {
            HttpContext.Current.Response.Write(strMessage);            
        }
       
        public static string Base64Encode(string stringText)
        {
            var stringTextBytes = Encoding.UTF8.GetBytes(stringText);
            return Convert.ToBase64String(stringTextBytes);
        }

        #endregion
    }
}
