﻿using System.Runtime.Serialization;

namespace TwitterFeedsApp.WcfService.DataContracts
{
    [DataContract]
    public class TwitterFeedsRequest
    {
        [DataMember]
        public string TwitterUser { get; set; }

        [DataMember]
        public int NumberOfFeedsToRetrieve { get; set; }
    }
}
