﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using TwitterFeedsApp.WcfService.DataContracts;

namespace TwitterFeedsApp.WcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service : IService
    {
        public List<Tweet> RetrieveUserTweets(TwitterFeedsRequest twitterFeedsRequest)
        {
            Task<List<Tweet>> task = GetTweets(twitterFeedsRequest.TwitterUser, twitterFeedsRequest.NumberOfFeedsToRetrieve);

            task.Wait();


            return task.Result;
        }

        #region Utility Functions

        static async Task<List<Tweet>> GetTweets(string user, int count)
        {
            try
            {
                var twitterAPI = string.Format("{0}?screen_name={1}&count={2}", ConfigurationManager.AppSettings["TwitterAPI"], user, count);
                var twitterAppName = ConfigurationManager.AppSettings["TwitterAppName"];

                string bearer = GetBearerAsync().Result;

                using (var client = new HttpClient())
                {
                    string auth = "Bearer " + bearer;

                    client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", auth);
                    client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", twitterAppName);

                    var response = await client.GetAsync(twitterAPI);
                    var responseContent = await response.Content.ReadAsStringAsync();


                    var tweets = JsonConvert.DeserializeObject<List<Tweet>>(responseContent);

                    return tweets;
                }

            }
            catch (Exception ex)
            {

            }

            return null;
        }
        static async Task<string> GetBearerAsync()
        {
            using (var client = new HttpClient())
            {
                string key = ConfigurationManager.AppSettings["TwitterKey"];
                string secret = ConfigurationManager.AppSettings["TwitterSecret"];

                string keyEncoded = HttpUtility.UrlEncode(key);
                string secretEncoded = HttpUtility.UrlEncode(secret);

                string keySecretEncoded = Base64Encode(keyEncoded + ":" + secretEncoded);
                string credentials = ("Basic " + keySecretEncoded);

                string uri = "https://api.twitter.com/oauth2/token";
                string contentType = "application/x-www-form-urlencoded;charset=UTF-8";
                //Add headers, skip validation that throws false errors
                client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", credentials);
                client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", contentType);

                //post body
                var values = new Dictionary<string, string> { { "grant_type", "client_credentials" } };
                var body = new FormUrlEncodedContent(values);

                var response = await client.PostAsync(uri, body);
                var payload = await response.Content.ReadAsStringAsync();

                //Deserialize JSON into TwitterResponse object
                var ser = new JavaScriptSerializer();
                TwitterResponse TwitterResponse = ser.Deserialize<TwitterResponse>(payload);

                string bearer = TwitterResponse.access_token;

                return bearer;
            }
        }

        public static string Base64Encode(string stringText)
        {
            var stringTextBytes = Encoding.UTF8.GetBytes(stringText);
            return Convert.ToBase64String(stringTextBytes);
        }

        #endregion
    }
}
