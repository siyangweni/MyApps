﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Serialization
{
    public class Serializer
    {
        public static object Deserialize(byte[] xmlByteData)
        {
            try
            {
                XmlSerializer ds = new XmlSerializer(typeof(object));
                MemoryStream memoryStream = new MemoryStream(xmlByteData);
                object obj = new object();
                obj = ds.Deserialize(memoryStream);
                return obj;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public static String Serialize(object obj)
        {
            try
            {
                String XmlizedString = null;
                XmlSerializer xs = new XmlSerializer(typeof(object));
                MemoryStream memoryStream = new MemoryStream();
                
                XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.UTF8);
                xs.Serialize(xmlTextWriter, obj);
                
                memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
                
                XmlizedString = UTF8ByteArrayToString(memoryStream.ToArray());
                return XmlizedString;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private static String UTF8ByteArrayToString(Byte[] characters)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            String constructedString = encoding.GetString(characters);
            return (constructedString);
        }
    }
}
