﻿using System;

namespace TwitterFeedsApp.CrossCuttingConcerns.Contracts
{
    public interface ILogger
    {
        void Error(string message);
        void Info(string message);
        void FatalError(Exception exception);
    }
}
