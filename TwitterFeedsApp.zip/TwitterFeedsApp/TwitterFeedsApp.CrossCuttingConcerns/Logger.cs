﻿using System;
using log4net;
using TwitterFeedsApp.CrossCuttingConcerns.Contracts;

namespace TwitterFeedsApp.CrossCuttingConcerns
{
    public class Logger :ILogger
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(Logger));

        public Logger()
        {
            log4net.Config.XmlConfigurator.Configure();
        }

        public void Error(string message)
        {
            logger.Error(message);
        }

        public void Info(string message)
        {
            logger.Info(message);
        }

        public void FatalError(Exception exception)
        {
            logger.Error(exception.Message, exception);
        }
    }
}
